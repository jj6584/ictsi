<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

            public function index(){

                $this -> login();
            }


            public function login(){

                $this -> load -> view('admin/admin');
            }


                public function manage_hpcontent(){
              $this->load->model('model_admin');
              $data['contents']= $this->model_admin->get_hpcontent($id=1);
              $this->load->view('admin/manage_hpcontent',$data);
            }

            public function manage_footer($id=1){

              $this->load->model('model_admin');
              $data['posts']= $this->model_admin->get_footer($id);
              $this->load->view('admin/Manage_Footer', $data);
            }

            public function manage_carousel(){
              $this->load->model('model_admin');
              $data['photo']= $this->model_admin->get_banner($id=1);
            $this->load->view('admin/carousel',$data ,array('error' => ' ' ));
              //  $this ->load ->view('admin/carousel');
            }

            public function admin_validation(){

                 $this->load->library('form_validation');
                 $this->form_validation->set_rules('adminuser', 'Username', 'required|trim|callback_validate_admin');
                 $this->form_validation->set_rules('adminpass', 'Password', 'required|trim|sha1');

                 if($this->form_validation->run()){

                      $d = $this -> model_admin -> getDetails($this->input->post('adminuser'));

                      foreach ($d as $details) {
                        $data = array(

                          'admin_fname' => $details->admin_fname,
                          'admin_mname' => $details->admin_mname,
                          'admin_lname' => $details->admin_lname,
                          'admin_level' => $details->admin_level,
                          'admin_id' => $details->admin_id,
                          'is_logged_in' => 1

                          );
                      }

                      $this -> session -> set_userdata($data);

                      if($_SESSION['admin_level'] == 32){
                        redirect('admin/hr_dashboard');
                      }else{
                        redirect('admin/dashboard');
                      }


                      redirect('admin/dashboard');


                 }else{

                    $this -> load -> view('admin/admin');
                 }


            }


            public function add_FAQ(){
                $this -> load -> view('admin/add_FAQ');
            }
            public function dashboard(){
                $this -> load -> view('admin/banner');
            }

            // public function manage_footer(){

            //     $this -> load -> view('admin/Manage_Footer');
            // }

            public function manage_FAQ(){
                 $this->load->model('model_admin');

              $data['faq'] = $this->model_admin -> get_faqs();

                $this -> load -> view('admin/Manage_FAQ', $data);

            }

            // public function manage_carousel(){

            //     $this ->load ->view('admin/carousel');
            // }





            public function validateinsert(){

                $this -> load ->library('form_validation');
                $this -> form_validation -> set_rules('job_title', 'Job Title', 'required');
                $this -> form_validation -> set_rules('req_id', 'Requisition ID', 'required');
                $this -> form_validation -> set_rules('job_desc', 'Job Description', 'required');
                 $this -> form_validation -> set_rules('ha', 'Attainment', 'required');
                $this -> form_validation -> set_rules('skills', 'Skills', 'required');
                $this -> form_validation -> set_rules('program', 'Program', 'required');
                $this -> form_validation -> set_rules('number', 'Number', 'required');
                $this -> form_validation -> set_rules('year/month', 'Year and month', 'required');
                $this -> form_validation -> set_rules('emp_type', 'Employment type', 'required');




                $this -> load -> model('model_admin');
                  if($this->form_validation->run()){


                      if($this->model_admin->addjob()){

                      $this -> load -> view('admin/hr_dashboard');

                       }


                  }else{
                    $this -> load -> view('admin/hr_manage_jobs');
                  }

            }




            public function validate_admin(){

                    $this->load->model('model_admin');

                  if($this->model_admin->admin_log_in()){
                           return true;
                  }else{
                      $this->form_validation->set_message('validate_admin', 'Incorrect username or password');
                        return false;

                  }

            }


            public function logout(){

                  $this -> session ->sess_destroy();
                  redirect(base_url() . "admin");
            }

                    public function add_faqs(){

                      $this -> load -> library("form_validation");
                       $this -> load -> model('model_admin');
                      $this -> form_validation -> set_rules('question', "Question", "required");
                      $this -> form_validation -> set_rules('answer', "Answer", "required");

              if($this->form_validation->run()){



                 $data = array(
                  'question' => $this->input->post('question'),
                   'answer'=> $this->input->post('answer')
                   );

                 $this->model_admin->insert_faqs($data);
              redirect(base_url() . "admin/manage_FAQ/");

            }else{

              $this -> load -> view('admin/add_FAQ');
            }
}

         function view_update_FAQ($id){
              //$postid = $this->uri->segment(3);
             // $this->load->view('admin/update_FAQ');
        $this->load->model('model_admin');
              $data['post']= $this->model_admin->get_faqss($id);
              //print_r($data['post']);
            $this->load->view('admin/update_FAQ', $data);

            }


            function update_FAQ($id){
      // $data['success'] = 0;
               $this->load->model('model_admin');
            if($_POST){
              $data = array('question'=>$_POST['question'],
                            'answer'=>$_POST['answer']
                            );
               $this->model_admin->update_FAQ($id, $data);
               redirect(base_url() . "admin/manage_FAQ/");
              // $data['success'] = 1;
            }
   // $data['post']= $this->model_admin->get_post($postid);
    //print_r($data['post']);
   // $this->load->view('edit_post_view', $data);

  }



  function delete_FAQS($id){
    $this->load->model('model_admin');
    $this->model_admin->delete_faq($id);
            redirect(base_url() . "admin/manage_FAQ/");
  }


            public function get_faqs(){
              $this -> load -> model('model_admin');

            }







//uploading
  function do_upload()
  {
    $config['upload_path'] = './uploads/';
    $config['allowed_types'] = 'gif|jpg|png';
    $config['max_size'] = '2048000';
    $config['max_width']  = '1500';
    $config['max_height']  = '700';

    $this->load->library('upload', $config);

    if ( ! $this->upload->do_upload())
    {
      $error = array('error' => $this->upload->display_errors());
      $this->load->view('upload_form', $error);
    }
    else
    {
      $data = array('upload_data' => $this->upload->data());
      $this->load->view('upload_success', $data);
    }
  }










//HR ADMIN GOALS

public function hr_dashboard(){
  $this -> load -> model('model_admin');
    $this -> load -> view('admin/hr_dashboard');
}


public function addinterview(){

    $this -> load -> library('form_validation');
    $this -> load ->model('model_admin');
    $this -> form_validation -> set_rules('date', 'Date', 'required');
    $this -> form_validation -> set_rules('time', 'Time', 'required');
    $this -> form_validation -> set_rules('day', 'Day', 'required');
        $this -> form_validation -> set_rules('rmk', 'Requirement/comments', 'required');

        if($this->form_validation->run()){
                if($this->model_admin->inserintev()){
                    redirect('admin/hr_dashboard');
                }


          }else{

            $this -> load -> view('admin/hr_interviewSched');
          }

}



public function interview_sched(){
  $this ->load->model('model_admin');
    $this->load->view('admin/hr_interviewSched');
  }


function get_applicants()
{

  $this -> load -> library('form_validation');
  $this-> load ->model('model_admin');
  $this -> form_validation -> set_rules('thejob', 'Job', 'required');
      if($this->form_validation->run()){

                   $postid = $_POST['thejob'];
                   $data['datas'] = $this->model_admin->getAllapply($postid);
                     $this->load->view('admin/hr_dashboard', $data);
}else{
    $this -> load -> view('admin/hr_dashboard');
}

}

public function workflow(){
    $this -> load -> view('admin/hr_work_flow');
}

public function managejobs(){
  $this -> load -> model('model_users');
    $this -> load -> view('admin/hr_manage_jobs');
}

public function manageEmp(){
  $this -> load -> view('admin/hr_manage_empRecord');
}

public function interviewsched(){
    $this -> load -> view('admin/hr_interviewSched');
}



function update_footer($id=1){
  $this->load->model('model_admin');
  if($_POST){
    $data = array('copyright'=>$_POST['copyright'],
                  'fblink'=>$_POST['fb'],
                  'twitterlink' => $_POST['twitter']
                  );
    $this->model_admin->update_footer($id, $data);
    redirect(base_url() . "admin/manage_footer/");
  }

}







}