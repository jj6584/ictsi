<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {



	public function index()
	{

		$this -> login();
	}



	public function login()
	{
		$this->load->model('model_admin');
		$data['contents']= $this->model_admin->get_hpcontent($id=1);
		$data['posts']= $this->model_admin->get_footer($id=1);
		$data['photo']= $this->model_admin->get_banner($id=1);
		if($this->session->userdata('is_logged_in')){
			$this -> load -> model('model_users');
			$data['datas']	= $this -> model_users -> get_jobs();
			$this -> load -> view('applicant_page', $data);
		}else{
			$this -> load -> view('login', $data);
		}


	}


		public function job_description($job_id){
		$this->load->model('model_users');
		$data['jobdesc'] = $this->model_users->get_job_desc($job_id);
		$this->load->view('job_description', $data);
	}


	public function joblist(){
		$this -> load -> model('model_users');
		$data['datas'] = $this -> model_users -> get_jobs();
		$this -> load -> view('job_list', $data);

	}


	public function FAQs(){
		$this -> load -> model('model_users');
		$data['datas'] = $this -> model_users -> get_FAQS();
		$this -> load -> view('FAQ', $data);
	}




	public function test(){
		$this ->load->view('test');
	}


	public function login_validation()
	{

		$this -> load -> library('form_validation');
		$this -> load -> model('model_users');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim|callback_validate_credentials');
		$this->form_validation->set_rules('password', 'Password', 'required|trim|sha1');


		if($this -> form_validation -> run()){






			$d = $this -> model_users -> getDetails($this->input->post('email'));


			 $data = array();
			foreach ($d as $details ) {

				$data = array(

					'fname' => $details->fname,
					'mname' => $details->mname,
					'lname' => $details->lname,
					'college' => $details->college,
					'college_de' => $details->college_de,
					'college_inc' => $details->college_inc,
					'collegeprog' => $details->collegeprog,
					'skills' => $details->skills,
					'applicant_id' => $details->id,
					'email' => $details->email,
					'is_logged_in' => 1

					);


			}

			$match = $this -> model_users ->doMatch($this->session->userdata('skills'));
			$this -> session -> set_userdata($data);
			redirect('main/dashboard');

		}else{
			$this -> load -> model('model_admin');
			$data['contents']= $this->model_admin->get_hpcontent($id=1);
		$data['posts']= $this->model_admin->get_footer($id=1);
		$data['photo']= $this->model_admin->get_banner($id=1);
			$this -> load ->view('login', $data);


		}



	}



	public function resume_validation(){
		$this -> load -> library('form_validation');
		$this -> load -> model('model_users');
		$this -> form_validation -> set_rules('ha', 'Highest Attainment', 'required');
		$this -> form_validation -> set_rules('college', 'College', 'required');
		$this -> form_validation -> set_rules('college_de', 'Degree Earned', 'required');
		$this -> form_validation -> set_rules('collegeprog', 'College Program', 'required');
		$this -> form_validation -> set_rules('college_inc', 'College year graduated', 'required');



		if($this->form_validation->run()){

			$_SESSION['ha'] = $this->input->post('ha');
			$_SESSION['college'] = $this->input->post('college');
			$_SESSION['college_de'] = $this->input->post('college_de');
			$_SESSION['college_inc'] = $this->input->post('college_inc');
			$_SESSION['collegeprog'] = $this->input->post('collegeprog');

			$this -> load -> view('reg_next');

		}else{

			$this -> load -> view('registration2');
		}

	}




	public function final_reg(){

		$this -> load -> library('form_validation');
		$this -> form_validation -> set_rules('firstc', 'First choice', 'required');
		$this -> form_validation -> set_rules('secondc', 'Second choice', 'required');
		$this -> form_validation -> set_rules('salary', 'Salary', 'required');
		$this -> form_validation -> set_rules('skills', 'Skills', 'required');
		//$this -> form_validation -> set_rules('years', 'Years', 'required');
		//$this -> form_validation -> set_rules('position', 'Position', 'required');
		$this -> form_validation -> set_rules('ref', 'Reference', 'required');
		//$this -> form_validation -> set_rules('ava', 'Date Available for Employment', 'required');



		if($this->form_validation->run()){

			$this -> load -> model('model_users');

			$_SESSION['poschoice1'] = $this->input->post('firstc');
			$_SESSION['poschoice2'] = $this->input->post('secondc');
			$_SESSION['salary'] = $this->input->post('salary');
			$_SESSION['skills'] = $this ->input->post('skills');
			$_SESSION['date_ava'] = $this->input->post('ava');
			$_SESSION['ref'] = $this->input->post('ref');


			 if($this->model_users->add_applicant()){


			 	$this -> session ->sess_destroy();
				redirect(base_url());


			 }

		}else{

			$this -> load -> model('model_users');
			$this -> load -> view('reg_next');
		}


	}






	public function validate_registration(){

		$this -> load -> library('form_validation');
		$this -> form_validation -> set_rules('fname', 'First Name', 'required|trim|alpha|max_length[30]');
		$this -> form_validation -> set_rules('mname', 'Middle Name', 'required|trim|max_length[30]');
		$this -> form_validation -> set_rules('lname', 'Last Name', 'required|trim|max_length[30]');
		$this -> form_validation -> set_rules('gender', 'Gender', 'required');
		$this -> form_validation -> set_rules('citizenship', 'Citizenship', 'required|trim|alpha|max_length[30]');
		$this -> form_validation -> set_rules('religion', 'Religion', 'required|trim|alpha');
		$this -> form_validation -> set_rules('height', 'Height', 'required|trim|numeric|callback_negativenum_h');
		$this -> form_validation -> set_rules('weight', 'Weight', 'required|trim|numeric|callback_negativenum_w');
		$this -> form_validation -> set_rules('city', 'City ', 'required');
		$this -> form_validation -> set_rules('state', 'State', 'required');
		$this -> form_validation -> set_rules('contact', 'Contact', 'required|trim|numeric');
		$this -> form_validation -> set_rules('email', 'Email', 'required|valid_email|trim|is_unique[applicants.email]');
		$this -> form_validation -> set_rules('password', 'Password', 'required|trim');
		$this -> form_validation -> set_rules('cpassword', 'Confirm Password', 'required|trim|matches[password]');
		$this -> form_validation -> set_rules('bdaym', 'Birthday Month', 'required');
		$this -> form_validation -> set_rules('bdayy', 'Birthday Year', 'required');
		$this -> form_validation -> set_rules('bdayd', 'Birthday Day', 'required');
		$this -> form_validation -> set_rules('sss', 'SSS No.', 'trim|numeric');
		$this -> form_validation -> set_rules('tin', 'TIN No.', 'trim|alpha_numeric');


		$this->form_validation->set_message('is_unique', 'That email address is already taken.');

		$this->load->model('model_users');

		if($this->form_validation->run()){
			// if($this->model_users->add_applicant()){
				$data = array(

				'fname' => $this->input->post('fname'),
				'mname' => $this->input->post('mname'),
				'lname' => $this->input->post('lname'),
				'gender' => $this->input->post('gender'),
				'citizenship' => $this->input->post('citizenship'),
				'religion' => $this->input->post('religion'),
				'height' => $this->input->post('height'),
				'weight' => $this->input->post('weight'),
				'city' => $this->input->post('city'),
				'state' => $this->input->post('state'),
				'contact' => $this->input->post('contact'),
				'email' => $this->input->post('email'),
				'password' => $this->input->post('password'),
				'bdayd' => $this->input->post('bdayd'),
				'bdaym' => $this->input->post('bdaym'),
				'bdayy' => $this->input->post('bdayy'),
				'sss' => $this->input->post('sss'),
				'tin' => $this->input->post('tin'),
				'college' => "",
				'college_de' => "",
				'collegeprog' => "",
				'college_inc' => 0,
				'salary' => 0,
				'poschoice1' => "",
				'poschoice2' => "",
				'skills' => "",
				'date_ava' => "",
				'ref' => ""







				);

			$this->session->set_userdata($data);


			// }

			$this -> load -> view('registration2');
		}else{
			$this -> load -> view('registration');
		}





	}



  public function insert_applicant(){

    $this -> load -> model('model_users');

    $applicant_id = $_POST['hidden_applicant_id'];

    $job_id = $_POST['hidden_job_id'];


	$data = array(
		          'job_id_tr' => $job_id,
		          'applicant_id_tr' => $applicant_id
		          );
      $this -> model_users ->insert_into_jobstransaction($data);





  }

  public function cancelApp(){
  	$this -> load ->model('model_users');

  	$applicant_id = $_POST['hidden_applicant_id'];

    	$job_id = $_POST['hidden_job_id'];
    	   $this -> model_users ->cancelApplication($applicant_id, $job_id);

  }






	public function negativenum_h($data){

		$this -> load ->model('model_users');

		if($data >1){


			return true;
		}else{
			$this -> form_validation -> set_message('negativenum_h', 'Height Must be positive number');
			return false;
		}



	}



	public function negativenum_w($data){

		$this -> load ->model('model_users');

		if($data >1){


			return true;
		}else{
			$this -> form_validation -> set_message('negativenum_w', 'Weight Must be positive number');
			return false;
		}



	}






	public function validate_credentials(){

		$this->load->model('model_users');

		if($this->model_users->can_log_in()){
			return true;
		}else{
			$this->form_validation->set_message('validate_credentials', 'Incorrect username or password');
			return false;
		}
	}





	public function apply(){

		$this -> load -> view('registration');
	}

	public function jobdesc(){

		$this -> load -> view("job_description");
	}

	public function last(){

		$this -> load -> model('model_users');

		$this -> load -> view('reg_next');
	}

	public function next(){
		$this -> load -> view('registration2');
	}

	public function dashboard(){
		$this -> load -> model('model_users');


		if($this->session->userdata('is_logged_in')){


		$this -> load -> view('applicant_page');
		}else{
			redirect('main');
		}
	}





  function update_carousel(){
   	 $config['upload_path']          = './images/';
        $config['allowed_types']     = 'gif|jpg|png';
        $config['max_size']          = 10000;

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        if ($this->upload->do_upload('userfile')) {
            $data = array('upload_data' => $this->upload->data());

           $img = $data['upload_data']['file_name'];
           $this->load->model('model_admin');
           $this->model_admin->update_banner($img);

            $this->load->view('admin/upload_success');
        }
        else {
          $error = array('error' => $this->upload->display_errors());
         $this->load->view('admin/upload_failed',$error);
        }
  }

  public function view_update_banner($id=1){
    $this->load->model('model_admin');
    $data['photo']= $this->model_admin->get_banner($id);
    $this->load->view('login', $data);
  }


  // EDIT PROFILE
  public function edit_profile(){
  	$this->load->view('edit_profile');
  }

  public function edit_skills(){
  	$this ->load->model('model_users');
  //	$skills = $this->model_users->getSkills();
  	$this -> load -> library('form_validation');
	$this -> form_validation -> set_rules('skills', 'Skills', 'required');


	if($this->form_validation->run()==FALSE){


  	$this->load->view('edit_skills');
  	}else{
  	$email = $_SESSION['email'];
  	$skills = $this->input->post('skills');
  	$this->model_users->update_skills($email,$kills);
  	$this->load->view('applicant_page');
  	}
  }
  public function edit_education(){
  	$this->load->model('model_users');
  	$this->load->library('form_validation');
  	$this -> form_validation -> set_rules('ha', 'Highest Attainment','required');
	$this -> form_validation -> set_rules('college', 'College','required');
	$this -> form_validation -> set_rules('college_de', 'Degree Earned','required');
	$this -> form_validation -> set_rules('collegeprog', 'College Program','required');
	$this -> form_validation -> set_rules('college_inc', 'College year graduated','required');



	$email = $_SESSION['email'];
	if($this->form_validation->run()==FALSE){
		$this->session->set_flashdata('result', '');
		$this->load->view('edit_education');

	}else{
	$data = array(

	'ha' => $this->input->post('ha'),
	'college' => $this->input->post('college'),
	'college_de' => $this->input->post('college_de'),
	'college_inc' => $this->input->post('college_inc'),
	'collegeprog' => $this->input->post('collegeprog')

		);
	$this->model_users->update_education($data,$email);
	$this->session->set_flashdata('result', 'Updated Succesfully!');
	redirect('main/edit_education');
  	}
  }

  public function edit_aboutme(){
  	$this->load->model('model_users');
  	$this->load->library('form_validation');
  	$this -> form_validation -> set_rules('fname', 'First Name', 'required|trim|alpha|max_length[30]');
	$this -> form_validation -> set_rules('mname', 'Middle Name', 'required|trim|max_length[30]');
	$this -> form_validation -> set_rules('lname', 'Last Name', 'required|trim|max_length[30]');
	$this -> form_validation -> set_rules('gender', 'Gender', 'required');
	$this -> form_validation -> set_rules('citizenship', 'Citizenship', 'required|trim|alpha|max_length[30]');
	$this -> form_validation -> set_rules('religion', 'Religion', 'required|trim|alpha');
	$this -> form_validation -> set_rules('height', 'Height', 'required|trim|numeric|callback_negativenum_h');
	$this -> form_validation -> set_rules('weight', 'Weight', 'required|trim|numeric|callback_negativenum_w');
	$this -> form_validation -> set_rules('city', 'City ', 'required');
	$this -> form_validation -> set_rules('state', 'State', 'required');
	$this -> form_validation -> set_rules('contact', 'Contact', 'required|trim|numeric');
	$this -> form_validation -> set_rules('email', 'Email', 'required|valid_email|trim|is_unique[applicants.email]');
	$this -> form_validation -> set_rules('password', 'Password', 'required|trim');
	$this -> form_validation -> set_rules('cpassword', 'Confirm Password', 'required|trim|matches[password]');
	$this -> form_validation -> set_rules('bdaym', 'Birthday Month', 'required');
	$this -> form_validation -> set_rules('bdayy', 'Birthday Year', 'required');
	$this -> form_validation -> set_rules('bdayd', 'Birthday Day', 'required');
	$email = $_SESSION['email'];
	if($this->form_validation->run()==FALSE){
		$this->load->view('edit_aboutme');
			$this->session->set_flashdata('result', '');

	}else{

		$bday = $_POST['bdayy']. "-". $_POST['bdaym']. "-". $_POST['bdayd'];
  	$data = array(

				'fname' => $this->input->post('fname'),
				'mname' => $this->input->post('mname'),
				'lname' => $this->input->post('lname'),
				'gender' => $this->input->post('gender'),
				'citizenship' => $this->input->post('citizenship'),
				'religion' => $this->input->post('religion'),
				'height' => $this->input->post('height'),
				'weight' => $this->input->post('weight'),
				'city' => $this->input->post('city'),
				'state' => $this->input->post('state'),
				'contact' => $this->input->post('contact'),
				'email' => $this->input->post('email'),
				'password' => $this->input->post('password'),
				'bday' => $bday
				);
  	$this->model_users->update_aboutme($data,$email);
	$this->session->set_flashdata('result', 'Updated Succesfully!');
  	redirect('main/edit_aboutme');
  	}
  }

  public function edit_addinfo(){
  	$this->load->model('model_users');
  	$this->load->library('form_validation');

  	$this -> form_validation -> set_rules('salary', 'Salary','required');
	$this -> form_validation -> set_rules('years', 'Years');
	$this -> form_validation -> set_rules('position', 'Position');
	$email = $_SESSION['email'];
	if($this->form_validation->run()==FALSE){
		$this->session->set_flashdata('result', '');
		$this->load->view('edit_addinfo');

	}else{
	$data = array(

	'salary' => $this->input->post('salary')

		);
	$this->model_users->update_addinfo($data,$email);
	$this->session->set_flashdata('result', 'Updated Succesfully!');
  	$this->load->view('edit_addinfo');
  	}
  }



  // END EDIT PROFILE

	public function logout()
	{
		$this -> session ->sess_destroy();
		redirect(base_url());
	}



}
