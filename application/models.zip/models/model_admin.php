<?php



/**
*
*/
class Model_admin extends CI_Model
{


    public function admin_log_in()
    {
        $this ->db->where('admin_username', $this->input->post('adminuser'));
        $this ->db->where('admin_password', sha1($this->input->post('adminpass')));

        $query = $this->db->get('admin');

        if($query->num_rows() == 1){
            return true;
        }else{
            return false;
        }
    }


    public function getDetails($user){

             $this -> db -> select('*');
             $this -> db -> from('admin');
             $this -> db -> where('admin_username', $user);
             $query = $this->db->get();

             return $query->result();

        }

    public function insert_faqs($data)
    {
         $this->db->insert('faqs', $data);

    }

    public function get_faqs()
    {
             $this -> db -> select('*');
             $this -> db -> from('faqs');

             $query = $this->db->get();

             return $query->result_array();
    }


    function get_faqss($id){
        $this->db->select('*');
        $this->db->from('faqs');
        $this->db->where(array('id'=>$id));
         $query =  $this->db->get();
         return $query->first_row('array');
        }
      function update_faq($id,$data){
           $this->db->where('id', $id);
           $this->db->update('faqs', $data);
       }


    function delete_faq($id){
        $this->db->where('id',$id);
       $this->db->delete('faqs');
    }


    function update_footer($id,$data){
           $this->db->where('id', $id);
           $this->db->update('cms', $data);
       }
           function get_footer($id=1){
        $this->db->select('*');
        $this->db->from('cms');
        $this->db->where(array('id'=>$id));
         $query =  $this->db->get();
         return $query->first_row('array');
        }


            function update_banner($img){
        $id = 1;

    $updated = array('banner' => $img);
    $this->db->select('banner');
        $this->db->where('id', $id);
     $this->db->update('cms', $updated);


    }

    function get_banner($id=1){
        $this->db->select('banner');
        $this->db->from('cms');
        $this->db->where(array('id'=>$id));
         $query =  $this->db->get();
         return $query->first_row('array');
        }



////////////////////////////////////////////////////////////////
        function update_hpcontent($id,$data){
            $this->db->select('title','content');
           $this->db->where('id', $id);
           $this->db->update('cms', $data);
       }
           function get_hpcontent($id=1){
        $this->db->select('*');
        $this->db->from('cms');
        $this->db->where(array('id'=>$id));
         $query =  $this->db->get();
         return $query->first_row('array');
        }



        public function inserintev(){

            $data = array(
                    'int_date' => $this->input->post('date'),
                    'time' => $this->input->post('time'),
                    'day' => $this->input->post('day'),
                    'req_cmt' => $this->input->post('rmk'),
                    'int_user_id' =>$this->input->post('uid'),
                    'int_job_id' =>$this->input->post('jid'),
                    'int_hr_id' =>$_SESSION['admin_id']


                );

            $sql = $this -> db -> insert('interview_sched', $data);

            if($sql){
                return true;
            }else{
                return false;
            }



        }


public function getUserdetails($id){

             $this -> db -> select('*');
             $this -> db -> from('applicants');
             $this -> db -> where('id', $id);
             $query = $this->db->get();

             return $query->result_array();

        }


    public function addjob(){

        $work = $_REQUEST['number'] . " ". $_REQUEST['year/month'];


        $data = array(

                'job_title' => $this->input->post('job_title'),
                'job_desc' => $this->input->post('job_desc'),

                'job_skills' => $this->input->post('skills'),
                'work_area' => $this->input->post('program'),
                'work_exp' => $work,
                'highest_att' => $this->input->post('ha'),
                'exp_salary' => $this->input->post('salary'),
                'employment_type' => $this->input->post('emp_type'),

                'job_requisition_id' => $this->input->post('req_id'),
            );


        $query = $this -> db -> insert('jobs', $data);
        if($query){
                return true;
        }else{
            return false;
        }
    }



function getAllapply($jobid)
{
    $this -> db -> select("job_applicant_transact.*,applicants.*,jobs.*");
    $this -> db -> from('job_applicant_transact');
    $this -> db -> join("applicants", "applicants.id = job_applicant_transact.applicant_id_tr");
    $this -> db -> join("jobs", "jobs.job_id = job_applicant_transact.job_id_tr");
    $this -> db -> where("jobs.job_id",$jobid);
    $query = $this->db->get();
    return $query->result_array();

}





public function jobOpen(){

    $this -> db -> select('*');
    $this -> db -> from('jobs');
    $this -> db -> where('job_status', 1);
    $query = $this->db->get();

             return $query->result_array();
}












}