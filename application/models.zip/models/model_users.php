<?php



/**
*
*/
class Model_users extends CI_Model
{

     public function can_log_in()
    {
        $this ->db->where('email', $this->input->post('email'));
        $this ->db->where('password', sha1($this->input->post('password')));

        $query = $this->db->get('applicants');

        $query -> result_array();

        if($query->num_rows() == 1){


            return true;

        }else{

            return false;
        }
    }


    public function disable($job,$applicant){
        $this -> db -> select("*");
        $this -> db -> from("job_applicant_transact");
        $this -> db -> where("job_id_tr", $job);
        $this -> db -> where("applicant_id_tr", $applicant);
        $query = $this -> db -> get();

        $query -> result_array();

        if($query->num_rows() == 1){
            return true;
        }else{
            return false;
        }


    }


        public function getDetails($email){

             $this -> db -> select('*');
             $this -> db -> from('applicants');
             $this -> db -> where('email', $email);
             $query = $this->db->get();

             return $query->result();

        }







        public function insert_into_jobstransaction($data){
       if($this -> db -> insert('job_applicant_transact', $data)){
               redirect(base_url() . "main/dashboard");
            }else{
               return false;
         }

    }


public function get_job_desc($job_id){
    $this->db->select('*');
    $this->db->from('jobs');
    $this->db->where('job_id', $job_id);
    $query = $this->db->get();

   // return $query->result();
     return $query->row_array();
}

      public function add_applicant(){


        $birthday = $this->session->userdata('bdayy') ."-". $this->session->userdata('bdaym') ."-". $this->session->userdata('bdayd');





        $data = array(

                    'fname' => $_SESSION['fname'],
                    'mname' => $_SESSION['mname'],
                    'lname' => $_SESSION['lname'],
                    'state' => $_SESSION['state'],
                    'email' => $_SESSION['email'],
                    'password' => sha1($_SESSION['password']),
                    'contact' => $_SESSION['contact'],
                    'citizenship' => $_SESSION['citizenship'],
                    'religion' => $_SESSION['religion'],
                    'height' => $_SESSION['height'],
                    'weight' => $_SESSION['weight'],
                    'city_add' => $_SESSION['city'],
                    'state' => $_SESSION['state'],
                    'birthday' => $birthday,
                    'poschoice1' => $_SESSION['poschoice1'],
                    'poschoice2' => $_SESSION['poschoice2'],
                    'skills' => $_SESSION['skills'],
                    'salary' => $_SESSION['salary'],
                    'date_ava' => $_SESSION['date_ava'],
                    'reference' => $_SESSION['ref'],
                    'collegeprog' => $_SESSION['collegeprog'],
                    //'sss_no' => $this->input->post('sss'),
                   // 'tin_no' => $this->input->post('tin'),
                    //'elementary' => $this->input->post('elem'),
                    //'elem_de' => $this->input->post('deelem'),
                    //'elem_inc' => $this->input->post('inclusiveelem'),
                    //'highschool' => $this->input->post('hs'),
                    //'hs_de' => $this->input->post('dehs'),
                    //'hs_inc' => $this->input->post('inclusivehs'),
                    'college' => $_SESSION['college'],
                    'college_de' => $_SESSION['college_de'],
                    'college_inc' => $_SESSION['college_inc'],

                    //'technical_courses' => $this->input->post('techcourse'),
                    //'tech_de' => $this->input->post('detechcourse'),
                    //'tech_inc' => $this->input->post('inclusivetech'),
                    //'graduate_stud' => $this->input->post('cstudies'),
                    //'graduate_de' => $this->input->post('decstudies'),
                    //'graduate_inc' => $this->input->post('inclusivecstudies'),
                    //'post_graduate' => $this->input->post('postgrad'),
                    //'post_de' => $this->input->post('depostgrad'),
                    //'post_inc' => $this->input->post('inclusivepostgrad'),
                    //'licensure_exam' => $this->input->post('license'),
                    //'date_taken' => $this->input->post('datelicense'),
                    //'rating' => $this->input->post('rating'),
                    'level' => 1


            );

   $query = $this -> db -> insert('applicants', $data);
        if($query){
                return true;
        }else{
            return false;
        }

    }

    public function cancelApplication($appid,$jobid){


        $this -> db -> where("applicant_id_tr", $appid);
        $this -> db -> where("job_id_tr", $jobid);
        if($this -> db -> delete("job_applicant_transact")){
                redirect(base_url() . "main");
        }else{
            return false;
        }


    }

    public function get_jobs(){

            $this -> db ->select('*');
            $this -> db -> from('jobs');
            $this -> db -> where('job_status', 1);
            $this->db->order_by('date_added', 'DESC');
            $this->db->limit(10, 0);

             $query = $this->db->get();

             return $query->result_array();

        }

    public function doMatch($pattern){

        $var = explode(",", $pattern);

        $this -> db -> select('*');
        $this -> db -> from('jobs');
        foreach ($var as $newPattern) {
            $this -> db -> like('job_skills', $newPattern);
        }

        $sql = $this->db->get();
        return $sql -> result_array();

    }

    public function getSkills(){
        $this -> db -> select('*');
        $this -> db -> from('skills');
        $sql = $this -> db ->get();
        return $sql ->result_array();

    }


    public function getPosition(){


        $this -> db -> select('job_title');
        $this -> db -> from('jobs');
        $sql = $this ->db->get();
        return $sql ->result_array();
    }







        public function get_FAQS(){

            $this -> db -> select('*');
            $this -> db -> from('faqs');
            $this->db->order_by('date_posted', 'DESC');

            $sql = $this -> db ->get();

            return $sql->result_array();

        }












                public function convert_datetime($str) {

                          list($date, $time) = explode(' ', $str);
                         list($year, $month, $day) = explode('-', $date);
                         list($hour, $minute, $second) = explode(':', $time);
                          $timestamp = mktime($hour, $minute, $second, $month, $day, $year);
                         return $timestamp;
                     }


                    public function makeAgo($timestamp){

                            $difference = time() - $timestamp;
                            $periods = array("sec", "min", "hr", "day", "week", "month", "year", "decade");
                            $lengths = array("60","60","24","7","4.35","12","10");
                            for($j = 0; $difference >= $lengths[$j]; $j++)
                                $difference /= $lengths[$j];
                                $difference = round($difference);
                            if($difference != 1) $periods[$j].= "s";
                                $text = "$difference $periods[$j] ago";
                                return $text;
                     }



// UPDATE PROFILE //
public function update_skills($email,$skills){
    $data = array (
        'skills'=>$skills);
    $this->db->from('applicants');
     $this->db->where('email',$email);
    $this->db->update('skills',$data);

}

public function update_education($data,$email){
    $data = array(

    'highest_att' => $this->input->post('ha'),
    'college' => $this->input->post('college'),
    'college_de' => $this->input->post('college_de'),
    'college_inc' => $this->input->post('college_inc'),
    'collegeprog' => $this->input->post('collegeprog')

    );
   $this->db->from('applicants');
   $this->db->where('email',$email);
   $this->db->update('applicants',$data);
}
public function get_education($a_id){
    $this->db->select('*');
    $this->db->from('applicants');
    $this->db->where('id',$a_id);
    $query = $this->db->get();
    return $query->result_array();
}

public function update_addinfo($data,$email){
    $data = array(

    'salary' => $this->input->post('salary')

        );
     $this->db->from('applicants');
   $this->db->where('email',$email);
   $this->db->update('applicants',$data);
}
public function update_aboutme($data,$email){

        $bday = $_POST['bdayy']. "-". $_POST['bdaym']. "-". $_POST['bdayd'];
        $data = array(

            'fname' => $this->input->post('fname'),
            'mname' => $this->input->post('mname'),
            'lname' => $this->input->post('lname'),
            'gender' => $this->input->post('gender'),
            'citizenship' => $this->input->post('citizenship'),
            'religion' => $this->input->post('religion'),
            'height' => $this->input->post('height'),
            'weight' => $this->input->post('weight'),
            'city_add' => $this->input->post('city'),
            'state' => $this->input->post('state'),
            'contact' => $this->input->post('contact'),
            'email' => $this->input->post('email'),
            'password' => sha1($this->input->post('password')),
            'birthday' => $bday
         );

    $this->db->from('applicants');
   $this->db->where('email',$email);
   $this->db->update('applicants',$data);
}







}