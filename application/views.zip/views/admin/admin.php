<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="<?php echo base_url()?>css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="<?php echo base_url()?>css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="<?php echo base_url()?>js/bootstrap.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url()?>css/styles.css">

<div class="box">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><strong><center>Login</center></strong></h3>
  </div>

  <div class="panel-body">

	<div class="table-responsive">
   <?php echo form_open('admin/admin_validation');?>
  <div class="form-group">
    <label for="exampleInputEmail1">Username</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Username" name="adminuser">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="adminpass">
  </div>
  <button type="submit" class="btn btn-default pull-right">Login</button>

  <?php echo validation_errors();?>
<?php echo form_close();?>
</div>

  </div>
</div>
</div>