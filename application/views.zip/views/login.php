

<html>
	<head>

		<!--Bootstrap and JavaScript-->
		<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
 		<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
		<script src="<?php echo base_url();?>js/select2.min.js"></script>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/styles.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/select2.min.css">
		<style type ="text/css">

</style>

	<script type="text/javascript">
  		$('select').select2();
	</script>
	</head>

<body>

<!--Banner Text-->



<div class="tint">
<div class="banner-text">
	<p><font face="BEBAS"><?php echo $contents['title']?></font></p>
	</div>
	<div class="banner-text2">
	<p><center><?php echo $contents['content']?></center></p>
</div>
<?php 
 $this->load->model('model_admin');
//foreach ($photo as $key) {
	
?>
<div class="image fit"><img src="<?php echo base_url();?>images/<?php echo $photo['banner'];?>" ></div>

<?php echo form_open('main/login_validation'); ?>
<div class="userlogin-box form-group <?php if(form_error('email')){echo 'has-error';} ?>">
<input type="text" class="form-control" placeholder="Email" name="email" value="<?php echo set_value(form_error('email'));?>" >
 <?php if(form_error('email')){?>
<div class="alert alert-danger" role="alert">
<font size="2px"><?php echo form_error('email');?></font>

</div>
<?php }?>
	<!--
	<font color="white" size="2px"><?php echo form_error('email');?></font>
 -->
</div>

<div class="passlogin-box form-group">
<input type="password" class="form-control" placeholder="Password" name="password" >
<?php if(form_error('password')){?>
<div class="alert alert-danger" role="alert">
<font size="2px"><?php echo form_error('password');?></font>
</div>
<?php }?>
	<!-- <font color="white" size="2px"><?php echo form_error('password');?></font>
	 -->
</div>

<div class="buttonlogin-box">
<input type="submit" class="btn btn-primary" value="Login">
</div>



<!-- <div class="check-box">
 <p><input type="checkbox"> Remember me</p>
</div>
 -->

<?php echo form_close(); ?>

<div class="applybutton-box">
<!--  <p><input type="button" class="btn btn-primary btn-lg" value="Apply Now" role="button"></p>
 -->
 <p><a class="btn btn-primary btn-lg" href="<?php echo base_url()?>main/apply" role="button">Apply Now!</a></p>
 </div>

</div>

<!--<?php echo validation_errors();?>-->
<?php
                    $this->load->model('model_admin');
?>
<center><h3><?php echo $posts['copyright']?></h3></center>

	</body>
</html>