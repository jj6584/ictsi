<html>
	<head>

		<!--Bootstrap and JavaScript-->
		<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
 		<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>

		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/styles.css">

		<style type ="text/css"></style>

    <link href="<?php echo base_url();?>css/select2.min.css" rel="stylesheet" />
    <script src="<?php echo base_url();?>js/select2.min.js"></script>



	</head>
<body>


<div class="reg-box">
<div class="panel panel-default">
  <div class="panel-heading" style = "background-color: #FB8F40">
    <h3 class="panel-title" ><font face="BEBAS" size="30px"><center>Resume</center></font></h3>
  </div>
  <div class="panel-body" style = "background-color: #F8F8F8">

  <div class="resume-box">

<div class="panel panel-default reg-steps3">
  <div class="panel-heading">
    <h4>Step 1</h4>
  </div>
</div>

 <div class="panel panel-default reg-steps3A">
  <div class="panel-heading">
    <h4>Step 2</h4>
  </div>
</div>

<div class="panel panel-primary reg-steps3A">
  <div class="panel-heading">
    <h4>Step 3</h4>
  </div>
</div>

<br />
<br />
<br />
<br />
<br />
<?php echo form_open('main/final_reg');
$this -> load -> model('model_users');
$jobs = $this->model_users->getPosition();
$skills = $this->model_users->getSkills();

//   echo "<pre>";
//  print_r ($this->session->all_userdata());
// echo "</pre>";

?>
	 <p><font face="Nexa Light" size="3px">Position Applied for: </font></p>

  <div class="dropdown1">

  <!--1st Choice Dropdown-->
	<div class="form-group">

    <select class="form-control" id="sel1" name="firstc">
      <option disabled selected>1st Choice</option>
       <?php

       foreach ($jobs as $job) {
           echo "<option value='$job[job_title]'>$job[job_title]</option>";
       }
  ?>
    </select>

  </div>  <!--End of form-group class-->
  </div> <!--End of dropdown1 class-->

  <div class="dropdown2">

  <!--1st Choice Dropdown-->
  <div class="form-group">

    <select class="form-control" id="sel1" name="secondc">
      <option disabled selected>2nd Choice</option>
<?php

      foreach ($jobs as $job) {
         echo "<option value='$job[job_title]'>$job[job_title]</option>";
      }
  ?>
    </select>

  </div>  <!--End of form-group class-->
  </div> <!--End of dropdown2 class-->
  <br />
<br />
<br />

<p><font face="Nexa Light" size="3px">Expected Salary: </font></p>
  <div class="dropdown1">

  <!--1st Choice Dropdown-->
  <div class="form-group">

    <select class="form-control" id="sel1" name="salary">
      <option value="">Choose a Salary</option>
      <option value="10000">P 10,000.00</option>
      <option value="20000">P 20,000.00</option>
      <option value="30000">P 30,000.00</option>
      <option value="40000">P 40,000.00</option>
      <option value="50000">P 50,000.00</option>
      <option value="60000">P 60,000.00</option>
      <option value="70000">P 70,000.00</option>
      <option value="80000">P 80,000.00</option>
      <option value="90000">P 90,000.00</option>
      <option value="100000">P 100,000.00</option>
    </select>

  </div>  <!--End of form-group class-->
  </div> <!--End of dropdown1 class-->
<br />
<br />
<br />
<p><font face="Nexa Light" size="3px">Skills: </font></p>
  <!--Start of skills-box class-->
  <div class="skills-box">

<select class="js-example-basic-multiple" multiple="multiple" width="50%" name="skills">
  <?php
      foreach ($skills as $skill) {
          echo "<option value='$skill[skill_name]'>$skill[skill_name]</option>";
      }
        ?>
</select>
  </div>
  <!--End of skills-boxes class-->
<br />
<p><font face="Nexa Light" size="3px">Working Experience: </font></p>
  <div class="expi">
    Year:
    <input type="text" class="form-control" name="year" placeholder="How many years?" name="years">
  </div>

    <div class="expi-as">
    as a/an:
    <input type="text" class="form-control" name="year" placeholder="Position" name="position">
  </div>
<br />
<br />
<br />
<br />

	<p><font face="Nexa Light" size="3px">Reference / Source of Job Vacancy: </font></p>
  <!--Start of check-boxes class-->
  <div class="radio-boxes">

  <div class="radio">
    <label><input type="radio" value="Newspaper Ad" name="ref">Newspaper Ad</label>
  </div>

  <div class="radio">
    <label><input type="radio" value="Walk-in" name="ref">Walk-in</label>
  </div>

  <div class="radio">
    <label><input type="radio" value="School Campaign" name="ref">School Campaign</label>
  </div>
  <!--Start of others-box class-->
  <div class="others-box">
  <input type="text" class="form-control" name="others" placeholder="Others" name="ref">
  </div>

  </div>
  <!--End of check-boxes class-->

    <!--Start of Date Available for Employment-->
  <br/ >
  <br />

  <p><font face="Nexa Light" size="3px">Date Available for Employment: </font></p>
  <!--Start of check-boxes class-->
  <div class="radio-boxes">

  <div class="radio">
    <label><input type="radio" value="Immediately" name="ava">Immediately</label>
  </div>

  <div class="radio">
    <label><input type="radio" value="Needs Few Weeks Notice" name="ava">Needs Few Weeks Notice</label>
  </div>



</div>

<nav>
  <ul class="pager">

    <li class="next"><?php echo form_submit('submit', 'Register');?></li>
  </ul>
</nav>
    <!--End of Pager-->
  <!--End of check-boxes class-->
</div>

  <!--End of Date Available for Employment-->
    <!--Pager: Next and Back-->
<?php if(validation_errors()){?>
    <div class="alert alert-danger" role="alert">
      <font size="2px"><?php echo validation_errors();?></font>

    </div>
<?php
}

?>


  </div>



  </div><!--Closing Panel Body-->

  </div><!--Closing Whole Panel-->
</div>


    <script type="text/javascript">
       $('select').select2();
       $(".js-example-basic-multiple").select2({placeholder: "Select your Skills", width: '100%' });
    </script>

</body>
</html>

