<html>
	<head>

		<!--Bootstrap and JavaScript-->
		<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
 		<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>

		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/styles.css">




    <link href="<?php echo base_url();?>css/select2.min.css" rel="stylesheet" />
    <script src="<?php echo base_url();?>js/select2.min.js"></script>

	</head>
<body>


<div class="reg-box">
<div class="panel panel-default">
  <div class="panel-heading" style = "background-color: #FB8F40">
    <h3 class="panel-title"><font face="BEBAS" size="30px"><center>Registration</center></font></h3>
  </div>
  <div class="panel-body" style = "background-color: #F8F8F8">

  	<div class="panel panel-primary reg-steps">
  <div class="panel-heading">
    <h4>Step 1</h4>
  </div>
</div>

  	<div class="panel panel-defualt reg-steps1">
  <div class="panel-heading">
    <h4>Step 2</h4>
  </div>
</div>


  	<div class="panel panel-defualt reg-steps1A">
  <div class="panel-heading">
    <h4>Step 3</h4>
  </div>
</div>


<br />
<br />
    <?php echo form_open('main/validate_registration');?>

  	<!--First Name Field-->
  	<div class="reg-fname form-group <?php if(form_error('fname')){echo "has-error";}?>">
  		First Name:
    	<input type="text" class="form-control" placeholder="First Name" name="fname" value="<?php echo set_value('fname');?>">

	</div>

	<!--Middle Name Field-->
	<div class="reg-mname form-group <?php if(form_error('mname')){echo "has-error";}?>">
		Middle Name:
		<input type="text" class="form-control" placeholder="Middle Name" name="mname" value="<?php echo set_value('mname');?>" >
	</div>

	<!--Last Name Field-->
	<div class="reg-lname form-group <?php if(form_error('lname')){echo "has-error";}?>">
		Last Name:
		<input type="text" class="form-control" placeholder="Last Name" name="lname" value="<?php echo set_value('lname');?>" >
	</div>
	<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br>
	<div class="reg-sex">
		<p><font face="Nexa Light" size="3px">Sex: </font></p>
	</div>
  <!--Start of check-boxes class-->
  <div class="radio-boxes form-group <?php if(form_error('gender')){echo "has-error";}?>">
    <label class="radio-inline"><input type="radio" value="Male" name="gender">Male</label>
    <label class="radio-inline"><input type="radio" value="Female" name="gender">Female</label>

	</div>
	<!--End of check-boxes class-->


	<!--Citizenship Field-->
	<div class="reg-citizenship form-group <?php if(form_error('citizenship')){echo "has-error";}?>">
		Citizenship:
    	<input type="text" class="form-control" placeholder="Citizehship" name="citizenship" value="<?php echo set_value('citizenship');?>">
	</div>

	<!--Religion Field-->
	<div class="reg-religion form-group <?php if(form_error('religion')){echo "has-error";}?>">
		Religion:
		<input type="text" class="form-control" placeholder="Religion" name="religion" value="<?php echo set_value('religion');?>">
	</div>

	<!--Height Field-->
	<div class="reg-height form-group <?php if(form_error('height')){echo "has-error";}?>">
		Height (cm):
		<input type="text" class="form-control" placeholder="Height" name="height" value="<?php echo set_value('height');?>">
	</div>


	<!--Weight Field-->
	<div class="reg-weight form-group <?php if(form_error('weight')){echo "has-error";}?>">
		Weight (kg):
		<input type="text" class="form-control" placeholder="Weight" name="weight" value="<?php echo set_value('weight');?>">
	</div>

	<div class="reg-city">
		City:
		<select class="form-control form-group <?php if(form_error('city')){echo "has-error";}?>" id="sel1" name="city">
      		<option value="">Select City</option>
      		<option value="Alaminos">Alaminos</option>
      		<option value="Angeles">Angeles</option>
      		<option value="Antipolo">Antipolo</option>
      		<option value="Bacolod">Bacolod</option>
      		<option value="Bacoor">Bacoor</option>
      		<option value="Bago">Bago</option>
      		<option value="Bago">Bais</option>
      		<option value="Balanga">Balanga</option>
      		<option value="Batac">Batac</option>
      		<option value="Batangas">Batangas</option>
      		<option value="Bayawan">Bayawan</option>
      		<option value="Baybay">Baybay</option>
      		<option value="Biñan">Biñan</option>
      		<option value="Bislig">Bislig</option>
      		<option value="Bogo">Bogo</option>
      		<option value="Borongan">Borongan</option>
      		<option value="Butuan">Butuan</option>
    		</select>
	</div>

	<div class="reg-state form-group <?php if(form_error('state')){echo "has-error";}?>">
		State:
		<select class="form-control" id="sel2" name="state">
      		<option value="">Select State</option>
      		<option value="Agusan del Norte">Agusan del Norte</option>
      		<option value="Agusan del Sur">Agusan del Sur</option>
      		<option value="Albay">Albay</option>
      		<option value="Basilan">Basilan</option>
    		</select>
	</div>


	<!--Contact Number Field-->
	<div class="reg-contact form-group <?php if(form_error('contact')){echo "has-error";}?>">
		Contact No.:
		<input type="text" class="form-control" placeholder="Contact No." name="contact" value="<?php echo set_value('contact');?>">
	</div>

	<!--Email Address Field-->
	<div class="reg-email form-group <?php if(form_error('email')){echo "has-error";}?>">
		Email Address:
		<input type="text" class="form-control" placeholder="Email" name="email" value="<?php echo set_value('email');?>">
	</div>

	<!--Password Field-->
	<div class="reg-pass form-group <?php if(form_error('password')){echo "has-error";}?>">
		Password:
		<input type="password" class="form-control" placeholder="Password" name="password" >
	</div>

	<!--Confirm Password Field-->
	<div class="reg-cpass form-group <?php if(form_error('cpassword')){echo "has-error";}?>">
		Confirm Password:
		<input type="password" class="form-control" placeholder="Confirm Password" name="cpassword" >
	</div>

	<!--Birthday Field-->
	<div class="reg-month form-group <?php if(form_error('bday')){echo "has-error";}?>">
		Birthday:
		<select class="form-control" id="sel3" name="bdaym">
      		<option value="">Month</option>
      		<option value="01">January</option>
      		<option value="02">February</option>
      		<option value="03">March</option>
      		<option value="04">April</option>
      		<option value="05">May</option>
      		<option value="06">June</option>
      		<option value="07">July</option>
      		<option value="08">August</option>
      		<option value="09">September</option>
      		<option value="10">October</option>
      		<option value="11">November</option>
      		<option value="12">December</option>
    	</select>
	</div>

	<div class="reg-day form-group <?php if(form_error('bday')){echo "has-error";}?>">
		<select class="form-control" id="sel4" name="bdayd">
      		<option value="">Day</option>

            <?php

              for($x =1; $x<=31; $x++){

                  echo "<option value='$x'>$x</option>";
              }
            ?>
    	</select>
	</div>

	<div class="reg-year form-group <?php if(form_error('bday')){echo "has-error";}?>">
		<select class="form-control" id="sel5" name="bdayy">
      		<option value="">Year</option>


              <?php

                  for($x=1900; $x<=date('Y'); $x++){

                      echo "<option value='$x'>$x</option>";
                  }

              ?>
    	</select>
	</div>

	<!--SSS No. Field-->
	<div class="reg-sss form-group <?php if(form_error('sss')){echo "has-error";}?>">
		SSS No.:
		<input type="text" class="form-control" placeholder="SSS No." name="sss" value="<?php echo set_value('sss');?>">
	</div>

	<!--TIN No. Field-->
	<div class="reg-tin form-group <?php if(form_error('tin')){echo "has-error";}?>">
		TIN:
		<input type="text" class="form-control" placeholder="T.I.N" name="tin" value="<?php echo set_value('tin');?>">
	</div>

	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />


	<nav>
<?php if(validation_errors()){?>
    <div class="alert alert-danger" role="alert">
      <font size="2px"><?php echo validation_errors();?></font>

    </div>
<?php
}

?>


  <ul class="pager">

    <li><?php echo form_submit('submit', 'Next');?></li>
  </ul>
</nav>
    <?php echo form_close();?>
  </div><!--Closing Panel Body-->

  </div><!--Closing Whole Panel-->



</div>


    <script type="text/javascript">
       $('select').select2();
       $(".js-example-basic-multiple").select2({placeholder: "Select your Skills", width: '100%' });
    </script>

</body>
</html>