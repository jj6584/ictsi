<html>
  <head>

    <!--Bootstrap and JavaScript-->
    <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>

    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/styles.css">

    <style type ="text/css"></style>

    <link href="<?php echo base_url();?>css/select2.min.css" rel="stylesheet" />
    <script src="<?php echo base_url();?>js/select2.min.js"></script>



  </head>
<body>


<div class="reg-box">
<div class="panel panel-default">
  <div class="panel-heading" style = "background-color: #FB8F40">
    <h3 class="panel-title" ><font face="BEBAS" size="30px"><center>Resume</center></font></h3>
  </div>
  <div class="panel-body" style = "background-color: #F8F8F8">

  <div class="resume-box">

<div class="panel panel-default reg-steps2">
  <div class="panel-heading">
    <h4>Step 1</h4>
  </div>
</div>

    <div class="panel panel-primary reg-steps2A">
  <div class="panel-heading">
    <h4>Step 2</h4>
  </div>
</div>

<div class="panel panel-default reg-steps2B">
  <div class="panel-heading">
    <h4>Step 3</h4>
  </div>
</div>

<br />
<br />
<br />
<br />
<br />

<?php echo form_open('main/resume_validation');?>
  <!--Educational Background-->
  <p><font face="Nexa Light" size="3px">Educational Background: </font></p>
  <div class="reg-attainment form-group <?php if(form_error('ha')){echo "has-error";}?>">
  Highest Attainment:
   <select class="form-control" id="sel1" name="ha">
                      <option disabled selected>Select Attainment</option>
                      <option value="Vocational">Vocational Diploma / Short Couse Certificate</option>
                      <option value="Bachelors/College Degree">Bachelor's/College Degree</option>
                      <option value="Graduate Studies">Post Graduate Diploma / Master's Degree</option>
                      <option value="doctorate">Doctorate Degree</option>
                      <option value="Passed Licensure Exam">Professional License (Passed Board/Bar/Professional License Exam)</option>


                </select>
  </div>


  <!--Start of College-->
  <!--College Field-->
    <div class="reg-college form-group <?php if(form_error('college')){echo "has-error";}?>">
      College:
      <input type="text" class="form-control" placeholder="School" name="college" value="<?php echo set_value('college');?>">
  </div>

  <!--Degree Earned Field-->
  <div class="reg-college-deg form-group <?php if(form_error('college_de')){echo "has-error";}?>">
    <select class="form-control" id="sel1" name="college_de" value="<?php echo set_value('college_de');?>">
      <option value="">Degree Earned</option>
      <option value="Bachelor of Arts (B.A.)">Bachelor of Arts (B.A.)</option>
      <option value="Bachelor of Science (B.S.)">Bachelor of Science (B.S.)</option>
      <option value="Bachelor of Fine Arts (B.F.A.)">Bachelor of Fine Arts (B.F.A.)</option>
    </select>
  </div>

     <!--Program Field-->
  <div class="reg-college-program form-group <?php if(form_error('collegeprog')){echo "has-error";}?>">
    <select class="form-control" id="sel1" name="collegeprog" value="<?php echo set_value('collegeprog');?>">
      <option value="">Program</option>
      <optgroup label="Engineering">
      <option value="Engineering, Civil Engineering">Civil Engineering</option>
      <option value="Engineering, Industrial Engineering">Industrial Engineering</option>
      <option value="Engineering, Electrical Engineering">Electrical Engineering</option>
      <option value="Engineering, Computer Engineering">Computer Engineering</option>
      <option value="Engineering, Mechanical Engineering">Mechanical Engineering</option>
      </optgroup>
      <optgroup label="Computer Studies">
      <option value="Computer Studies, Information Technology">Information Technology</option>
      <option value="Computer Studies, Computer Science">Computer Science</option>
      <option value="Computer Studies, Multimedia Arts">Multimedia Arts</option>
      </optgroup>

    </select>
  </div>
  <!--End of Program Field-->

     <!--Inclusive Dates Field-->
  <div class="reg-college-indates form-group <?php if(form_error('college_inc')){echo "has-error";}?>">
    <input type="text" class="form-control" placeholder="year graduated" name="college_inc" value="<?php echo set_value('college_inc');?>">
  </div>
  <!--End of College-->

  <!--Start of Technical Course-->
  <!--College Field-->
    <div class="reg-tech">
      Technical Course:
      <input type="text" class="form-control" placeholder="School" >
  </div>

  <!--Degree Earned Field-->
  <div class="reg-tech-deg">
        <select class="form-control" id="sel1">
      <option>Degree Earned</option>
      <option>Associate of Arts (A.A.)</option>
      <option>Associate of Science (A.S.)</option>
      <option>Associate of Applied Science (A.A.S)</option>
    </select>
  </div>

   <!--Program Field-->
  <div class="reg-tech-program">
    <select class="form-control" id="sel1">
      <option>Program</option>
      <option>Program 1</option>
      <option>Program 2</option>
      <option>Program 3</option>
    </select>
  </div>
  <!--End of Program Field-->

     <!--Inclusive Dates Field-->
  <div class="reg-tech-indates">
    <input type="text" class="form-control" placeholder="Inclusive Dates">
  </div>
  <!--End of Technical Course-->

  <!--Start of Graduate Studies-->
  <!--Graduate Studies Field-->
    <div class="reg-gs">
      Graduate Studies:
      <input type="text" class="form-control" placeholder="School" >
  </div>

  <!--Degree Earned Field-->
  <div class="reg-gs-deg">
      <select class="form-control" id="sel1">
      <option>Degree Earned</option>
      <option>Maaster of Arts (M.A.)</option>
      <option>Master of Science (M.S.)</option>
      <option>Master of Business Administration (M.B.A.)</option>
      <option>Master of Fine Arts (M.F.A)</option>
    </select>
  </div>

    <!--Program Field-->
  <div class="reg-gs-program">
    <select class="form-control" id="sel1">
      <option>Program</option>
      <option>Program 1</option>
      <option>Program 2</option>
      <option>Program 3</option>
    </select>
  </div>
  <!--End of Program Field-->

  <!--Inclusive Field-->
  <div class="reg-gs-indates">
    <input type="text" class="form-control" placeholder="Inclusive Dates">
  </div>
  <!--End of Graduate Studies-->

  <!--Start of Post Graduate-->
  <!--Post Graduate Field-->
    <div class="reg-post">
      Post Graduate:
      <input type="text" class="form-control" placeholder="School" >
  </div>

  <!--Degree Earned Field-->
  <div class="reg-post-deg">
   <select class="form-control" id="sel1">
      <option>Degree Earned</option>
      <option>Doctor of Philosophy (Ph.D.)</option>
      <option>Juris Doctor (J.D.)</option>
      <option>Doctor of Medicine (M.D.)</option>
      <option>Doctor od Dentral Surgery (D.D.S.)</option>
    </select>
  </div>

       <!--Program Field-->
  <div class="reg-post-program">
    <select class="form-control" id="sel1">
      <option>Program</option>
      <option>Program 1</option>
      <option>Program 2</option>
      <option>Program 3</option>
    </select>
  </div>
  <!--End of Program Field-->

  <!--Inclusive Field-->
  <div class="reg-post-indates">
    <input type="text" class="form-control" placeholder="Inclusive Dates">
  </div>


  <!--End of Post Graduate-->

  <!--Start of Licensure-->
  <!--Licensure Field-->
  <div class="reg-license">
    Licensure Examination Taken:
      <input type="text" class="form-control" placeholder="Licensure Examination Taken" >
  </div>

  <!--Degree Earned Field-->
  <div class="reg-license-datestaken">
    Date Taken:
    <input type="date" class="form-control" placeholder="Dates Taken">
  </div>

  <!--Inclusive Field-->
  <div class="reg-license-rating">Rating:
    <input type="text" class="form-control" placeholder="Rating">
  </div>

  <!--End of Licensure-->

  <br />
<br />
<br />
  <nav>
  <ul class="pager">

    <li class="next"><?php echo form_submit('submit', 'Next');?></li>
  </ul>
</nav>
    <!--End of Pager-->
    <?php echo form_close();?>

    <?php if(validation_errors()){?>
    <div class="alert alert-danger" role="alert">
      <font size="2px"><?php echo validation_errors();?></font>

    </div>
<?php
}

?>
  </div><!--Closing Panel Body-->

  </div><!--Closing Whole Panel-->
</div>



    <script type="text/javascript">
       $('select').select2();
       $(".js-example-basic-multiple").select2({placeholder: "Select your Skills", width: '100%' });
    </script>

</body>
</html>


